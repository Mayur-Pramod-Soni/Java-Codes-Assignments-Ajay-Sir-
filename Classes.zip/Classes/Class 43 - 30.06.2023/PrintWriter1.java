import java.io.*;
class PrintWriter1
{
	public static void main(String args[]) throws IOException
	{	
		PrintWriter pw = new PrintWriter("Abcd.txt");
		pw.println('a');
		pw.println("MAyur");
		pw.println(100);
		pw.println(1000);
		pw.println("Welcome");
		pw.println("Bye");
		pw.flush();
		pw.close();
	}
}