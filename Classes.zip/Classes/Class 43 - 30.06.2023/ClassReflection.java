
import java.lang.Class.*;
import java.io.*;

interface I 
{

}
abstract class EMP1 implements Serializable,I
{

}
class ClassReflection
{
	public static void main(String args[])throws ClassNotFoundException
	{
		Class c = Class.forName("EMP1");
		System.out.println(c.getName());

		Class [] cl = c.getInterfaces();
		for(Class cc : cl)
		{
			System.out.println(cc.getName());
		}
	}
}