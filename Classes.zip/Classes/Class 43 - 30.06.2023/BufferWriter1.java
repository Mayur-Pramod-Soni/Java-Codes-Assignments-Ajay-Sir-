import java.io.*;
class BufferWriter1
{
	public static void main(String args[]) throws IOException
	{
		FileWriter fw = new FileWriter("ppp.txt");

		BufferedWriter bw = new BufferedWriter(fw);
		
		bw.write('a');
		bw.newLine();
		bw.write(100);
		bw.newLine();
		bw.write("Mayur");
		bw.write("Welcome");
		bw.write("Bye");
		bw.flush();
		bw.close();
	}
}