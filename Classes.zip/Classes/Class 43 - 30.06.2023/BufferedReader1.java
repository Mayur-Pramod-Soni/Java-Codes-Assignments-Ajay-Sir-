import java.io.*;
class BufferedReader1
{
	public static void main(String args[])throws IOException
	{
		FileReader fw = new FileReader("Abcd.txt");
		BufferedReader bw = new BufferedReader (fw);

		String str = bw.readLine();
		while(str != null)
		{
			System.out.println(str);
			str = bw.readLine();
		}
	}
}