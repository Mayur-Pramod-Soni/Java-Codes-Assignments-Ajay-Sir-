import java.io.*;
class Notes implements Serializable
{
	int i = 10 ;
 	int j = 20 ;
	transient int PID = 45;
	transient String PID2 = "Mayur";
}
class Ser_DeSer
{
	public static void main(String arsg[])throws IOException,ClassNotFoundException
	{	
		Notes obj = new Notes();
		
		FileOutputStream fout = new FileOutputStream("xyz.ser");
		ObjectOutputStream oout = new ObjectOutputStream(fout);

		oout.writeObject(obj);
		System.out.println("Done");

		FileInputStream fin = new FileInputStream("xyz.ser");
		ObjectInputStream oin = new ObjectInputStream(fin);
		
		Notes obj2 = (Notes)oin.readObject();
		
		System.out.println(obj2.i);
		System.out.println(obj2.j);
		System.out.println(obj2.PID);
		System.out.println(obj2.PID2);
	}
}