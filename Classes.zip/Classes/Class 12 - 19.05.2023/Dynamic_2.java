class A 
{
     void sum()
     {
          System.out.println("Parent Sum");
     }
}
class B extends A
{
     void sum()
     {
           System.out.println("Child Sum");
     }
}
class C extends B
{
     void sum()
     {
           System.out.println("C class-Child Sum");
     }
}
class Dynamic_2
{
     public static void main(String args [])
     {
          B obj1 ; 
          //obj = new A () ; // Gives Error to Parent class can't be accessed via child class in Dyanamic Binding
          //obj.sum();

          obj1 = new B();
          obj1.sum();

          obj1 = new C();
          obj1.sum();


          A obj ;
          obj = new A () ;
          obj.sum();

          obj = new B();
          obj.sum();

          obj = new C();
          obj.sum();
          
     }
}
      