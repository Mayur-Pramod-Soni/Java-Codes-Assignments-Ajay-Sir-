class X
{

}
class Y extends X
{

}
class A 
{
    /* X sum()
     {
          System.out.println("Parent-Sum");
          return null;
     }*/

    /* X sum()
     {
          System.out.println("Parent-Sum");
          return null;
     }*/

     Y sum()
     {
          System.out.println("Parent-Sum");
          return null;
     }
}
class B extends A 
{
     /*X sum()      // output Child-Sum
     {
          System.out.println("Child-Sum");
          return null;
     }*/

     /*Y sum()        // output Child-Sum
     {
          System.out.println("Child-Sum");
          return null;
     }*/
     
     X sum()        // error: sum() in B cannot override sum() in A
     X sum()
     {
          System.out.println("Child-Sum");
          return null;
     }
}
class Dynamic_3
{ 
     public static void main(String args [])
     {
          A obj = new B();
          obj.sum();
     }
}
 