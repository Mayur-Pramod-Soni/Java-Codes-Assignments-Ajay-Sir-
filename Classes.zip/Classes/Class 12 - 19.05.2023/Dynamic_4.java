class A 
{
    protected void sum()   // Output - Child-Sum
    {
         System.out.println("Parent-Sum");
    }

    /*public void sum()    // Error :- attempting to assign weaker access privileges; was public
    {
         System.out.println("Parent-Sum");
    }*/
}

class B extends A 
{
   /* void sum()  // Error:- due to before void default set and the priority of public is less than default
    {
         System.out.println("Child-Sum");
    }*/
    
    public void sum()  
    {
         System.out.println("Child-Sum");
    }
}

class Dynamic_4
{
    public static void main(String args [])
    {
         A obj = new B () ;
         obj.sum();
    }
}
 