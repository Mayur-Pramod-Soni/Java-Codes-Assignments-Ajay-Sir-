class A 
{
     void sum()
     {
          System.out.println("Parent Sum");
     }
}
class B extends A
{
     void sum()
     {
           System.out.println("Child Sum");
     }
}
class Dynamic_1
{
     public static void main(String args [])
     {
          A obj = new B () ;  // class A - Referance & class B - excess object 
          obj.sum();

          A obj1 = new A ();
          obj1.sum();

          //B obj1 = new A (); // Error--> incompatible types: A cannot be converted to B
          //obj2.sum();
     }
}
      