class Sample
{
    int a = 100;
    int b = 200;
}
class Demo1
{
    public static void main(String [] args )
    {
         Sample obj = new Sample();
         System.out.println(obj.a);
         obj.a = 500;
         System.out.println(obj.a);
    }
}