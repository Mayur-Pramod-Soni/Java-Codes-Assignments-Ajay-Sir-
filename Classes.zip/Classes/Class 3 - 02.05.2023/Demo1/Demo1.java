// Accessing class via static and non static object ;

import java.lang.*;
class Sample 
{ 
   int a = 10;
   int b = 20 ;
   static int s = 30  ;
   
   void f1()
   {
      f2();
      f3();
      System.out.println("Non Static , this is f1");
      System.out.println(a);
      System.out.println(b);
      System.out.println(s);
    }
    void f2()
    {
       System.out.println("Non Static , this is f2");
    }
    static void f3()
    {
       // f2() error;
       f4();
       //Sample.obj2 = new Sample();
       //obj2.f2();
       System.out.println("Static ,this is f3");
      // System.out.println(a);
      // System.out.println(b);
       System.out.println(s);
    }
    static void f4()
    {
       System.out.println("Static ,this is f4");
    }
}
class Demo1
{
    public static void main(String [] args)
    {
        // f1(); error
        // Sample.f1(); errror 
        Sample obj1 = new Sample();
        obj1.f1();
        obj1.f2();
        // f3() error;
        
        Sample.f3();
        Sample.f4();
        obj1.f4();
     }
}
   



