// Accessing class via static and non static object ;

import java.lang.*;
class Sample 
{ 
   int a = 10;
   int b = 20 ;
   static int s = 30  ;
   
   void f1()
   {
      f2();
      f3();
      System.out.println("Non Static , this is f1");
      System.out.println(a);
      System.out.println(b);
      System.out.println(s);
    }
    void f2()
    {
       System.out.println("Non Static , this is f2");
    }
    static void f3()
    {
       // f2() error;
       f4();
       //Sample.obj2 = new Sample();
       //obj2.f2();
       System.out.println("Static ,this is f3");
      // System.out.println(a);
      // System.out.println(b);
       System.out.println(s);
    }
    static void f4()
    {
       System.out.println("Static ,this is f4");
    }
}
class Demo2
{
    void f6()
    {
       f7(); 
       System.out.println("Non Static , f6 ");
    }
    void f7()
    {
       f8();
       System.out.println("Non Static , f7 ");
    }
    static void f8()
    {
        System.out.println("Static , f8 ");
    }   
        
    public static void main(String [] args)
    {
        // f6(); error
        // sample.f6() error;
        // Demo1.f6() error;
     
        Demo2 alpha = new Demo2();
        alpha.f6();
     }
}
   



