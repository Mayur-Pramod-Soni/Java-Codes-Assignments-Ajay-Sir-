import java.lang.*;

    class Alpha 
    { 
        int a,b,c ;
        void accept()
        { 
           a=100;
           b=200;
        }
        void sum()
        {
           c= a+b;
        }
        void display()
        {
           System.out.println("sum is " +c);
        }
     }
     class Bahu
     { 
        public static void main(String arr[] )
        { 
           Alpha box = new Alpha();
           box.accept();
           box.sum();
           box.display();
        }
      }