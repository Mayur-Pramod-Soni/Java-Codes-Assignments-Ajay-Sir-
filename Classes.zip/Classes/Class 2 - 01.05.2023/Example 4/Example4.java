import java.lang.*;

    class Alpha 
    { 
        int a,b ;
        static int c;
        void accept(int x, int y,int z)
        { 
           a = x;
           b = y;
           c = z;
        }
        void display()
        {
           System.out.println(" Variable  = " +a);
           System.out.println(" Variable  = " +b);
           System.out.println(" Variable  = " +c);
        }       
     }
     class Bahu3
     { 
        public static void main(String [] args )
        { 
           Alpha obj = new Alpha();
           obj.accept(10,20,30);
           obj.display();

           Alpha obj2 = new Alpha();
           obj2.accept(100,200,300);
           obj2.display();                      
        }
     }