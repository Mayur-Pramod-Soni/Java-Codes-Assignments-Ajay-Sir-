import java.lang.*;

    class Alpha 
    { 
        int a,b,c ;
        void accept()
        { 
           a=100;
           b=200;
           c= a+b;
           System.out.println("sum is " +c);
        }
       // void sum();
      //  void display();
     }
     class Bahu1
     { 
        public static void main(String arr[] )
        { 
           Alpha box = new Alpha();
           box.accept();
           
        }
     }