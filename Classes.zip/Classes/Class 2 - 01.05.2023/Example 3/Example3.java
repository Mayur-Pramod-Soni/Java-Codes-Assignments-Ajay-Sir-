import java.lang.*;

    class Alpha 
    { 
        int a,b,c ;
        void accept(int x, int y)
        { 
           a=100;
           b=200;
        }
        void sum()
        {
            c= a+b;
        }
        int display()
        {
           return c ; 
        }
       
       
     }
     class Bahu2
     { 
        public static void main(String [] args )
        { 
           Alpha obj = new Alpha();
           obj.accept(300,400);
           obj.sum();
           int z = obj.display();
           System.out.println("Result = " +z);
           
        }
     }