class String_Delete
{
	public static void main(String args [])
	{
		StringBuffer s1 = new StringBuffer ("Welcome");
		s1.delete(2,4);
		System.out.println(s1);

		String s2 = "Welcome";
		StringBuffer s3 = new StringBuffer(s2);
		s3.delete(2,4);
		System.out.println(s3);

	}
}