class StringBuffer1
{
	public static void main(String args [])
	{

		// 1st way to write 

		StringBuffer s1 = new StringBuffer("abc");
		System.out.println(s1);

		// 2nd Way to write 
		
		StringBuffer s2 = new StringBuffer();
		s2.append("abc");
		s2.insert(0,"Mayur");
		System.out.println(s2);

		StringBuffer s3 = new StringBuffer();	
		s3.append("abc");
		s3.insert(2,"Albert");
		System.out.println(s3);


	}
}