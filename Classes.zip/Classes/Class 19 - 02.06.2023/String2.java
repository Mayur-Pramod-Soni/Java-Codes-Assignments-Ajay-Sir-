class String2
{	
	public static void main (String ... args)
	{
		String s1 = new String("abc") ;
		String s2 = "abc" ;
		String s4 = s1 + s2 ;
		String s5 = "abcabc" ;
		
		System.out.println( s4 == s5 );
	}
}
