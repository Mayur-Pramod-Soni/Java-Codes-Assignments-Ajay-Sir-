class String_Append
{
	public static void main(String args [])
	{
		StringBuffer s1 = new StringBuffer();
		System.out.println(s1.append("abc"));
		
		s1.insert(2,"albert");
		System.out.println(s1);
	}
}