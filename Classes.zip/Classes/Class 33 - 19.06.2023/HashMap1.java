import java.util.*;
class HashMap1
{
	public static void main(String args[])
	{
		HashMap m = new HashMap();

		m.put(101,"abc");
		m.put(102,"albert");
		m.put(103,"www");
		m.put(104,"xyz");

		m.put(101,"MAyuR"); // Overide by the Last value of key if same key observed 

		m.put(105,"Arpan");
		
		System.out.println(m); // {101=MAyuR, 102=albert, 103=www, 104=xyz, 105=Arpan} 

		Set s = m.keySet();
		System.out.println(s);  // [101, 102, 103, 104, 105] output in Set Format and only KEy 

		Collection c = m.values();
		System.out.println(c);  // [MAyuR, albert, www, xyz, Arpan] Output -- to get values 

		Set s1 = m.entrySet();
		System.out.println(s1);  // [101=MAyuR, 102=albert, 103=www, 104=xyz, 105=Arpan]


	}
}