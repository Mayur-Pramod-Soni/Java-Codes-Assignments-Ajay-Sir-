import java.util.*;
class TreeMAP
{
	public static void main(String args[])
	{
		TreeMap m = new TreeMap();
		m.put(111,"Mayur");
		m.put(112,"Arpan");
		m.put(113,"Chaitenya");
		m.put(115,"Veer");
		m.put(116,"xxx");
		m.put(101,"abc");
		m.put(105,"Soni");
		
		System.out.println(m);
	}
} 

/* Output:---

{101=abc, 111=Mayur, 112=Arpan, 113=Chaitenya, 115=Veer, 116=xxx}

*/