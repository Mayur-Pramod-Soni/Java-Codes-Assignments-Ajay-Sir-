import java.util.*;
class LinkedHashMap_Iterate
{
	public static void main(String args[])
	{
		LinkedHashMap m = new LinkedHashMap();
		
		m.put(101,"Mayur");
		m.put(102,"Arpan");
		m.put(104,"Baggi");
		m.put(103,"Design");
	
		System.out.println(m);
		
		Set s = m.entrySet();

		Iterator itr = s.iterator();
		while(itr.hasNext())
		{
			Map.Entry m1 = (Map.Entry)itr.next();
		
			System.out.println(m1.getKey()+" : "+m1.getValue());
		}
	}
}
 

/*Output: ---


{101=Mayur, 102=Arpan, 104=Baggi, 103=Design}
101 : Mayur
102 : Arpan
104 : Baggi
103 : Design


*/