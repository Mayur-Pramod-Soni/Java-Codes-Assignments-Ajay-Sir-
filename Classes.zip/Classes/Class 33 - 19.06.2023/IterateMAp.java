import java.util.*;
class IterateMAp
{
	public static void main(String args[])
	{
		HashMap m = new HashMap();

		m.put(101,"abc");
		m.put(102,"albert");
		m.put(103,"www");
		m.put(104,"xyz");

		m.put(101,"MAyuR"); 
		m.put(105,"Arpan");
		
		System.out.println(m);
		
		Set s = m.entrySet();
		//Collection c  = m.values();
		
		Iterator itr = s.iterator();
		while(itr.hasNext())
		{
			Map.Entry m1 = (Map.Entry)itr.next();
			
			System.out.println(m1.getKey());
			System.out.println(m1.getValue());
		}
	}
}
	
/*Output:---

{101=MAyuR, 102=albert, 103=www, 104=xyz, 105=Arpan}
101
MAyuR
102
albert
103
www
104
xyz
105
Arpan

*/	