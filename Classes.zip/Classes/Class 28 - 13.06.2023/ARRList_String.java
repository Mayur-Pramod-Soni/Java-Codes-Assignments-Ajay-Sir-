import java.util.*;
class ARRList_String
{
	public static void main(String args[])
	{
		List<String> l = new ArrayList<String>();
		
		l.add("Mayur");
		l.add("albert");
		l.add("albert");
		l.add("hello");
		l.add("katappa");
		
		System.out.println(l);
	}
}


/* Output:----

[Mayur, albert, albert, hello, katappa]*/


