import java.util.*;

class ARRDemo
{
	public static void main(String args[])
	{
		//ArrayList l = new ArrayList(); // Case 1 

		List l = new ArrayList(); // Case 2 also valid due to List is also a Interface

		l.add(10);
		l.add("Mayur");
		l.add("albert");
		l.add(23.50);
		l.add("Katapaa");

		System.out.println(l);
	}
}


/*Output:---

Case 1 : ---
Note: ARRDemo.java uses unchecked or unsafe operations.
Note: Recompile with -Xlint:unchecked for details.*/