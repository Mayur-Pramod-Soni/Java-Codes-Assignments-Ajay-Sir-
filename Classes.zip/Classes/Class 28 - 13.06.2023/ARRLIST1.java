import java.util.*;

class ARRLIST1
{
	public static void main(String args[])
	{
		List <String> l = new ArrayList <String> (100);
		ArrayList <String> l1 = new ArrayList <String> (100);

		l.add("abc");
		l.add("albert");
		l.add("albert");
		l.add("hello");
		l.add("katappa");
		
		l.add("deepika");

		l1.addAll(l);
		
		System.out.println(l1.retainAll(l));
		System.out.println(l);

		System.out.println(l1.remove(l));
		System.out.println(l1);

		Collections.sort(l1);
		System.out.println(l1); // Output [abc, albert, albert, deepika, hello, katappa]
		
		Collections.sort(l1,Collections.reverseOrder());
		System.out.println(l1); // Output [katappa, hello, deepika, albert, albert, abc]

		List<String>unmodifiableList= Collections.unmodifiableList(l1);
		System.out.println(l1);   // to make List unmodifiable 
		
		l1.add("Mayur");
		System.out.println(l1);
		
		Set<String> s = new LinkedHashSet<String>(l1);  
        	System.out.println(s);  // Converting ArrayList to Set for remove Duplicacy...
	}
}


/*
Output:---

false
[abc, albert, albert, hello, Katappa, Deepika]
false
[abc, albert, albert, hello, Katappa, Deepika]

*/