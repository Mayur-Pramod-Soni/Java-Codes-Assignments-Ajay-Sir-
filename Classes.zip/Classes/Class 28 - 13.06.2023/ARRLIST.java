import java.util.*;

class ARRLIST
{
	public static void main(String args[])
	{
		List <String> l = new ArrayList <String> ();
		List <String> l1 = new ArrayList <String> ();

		l.add("abc");
		l.add("albert");
		l.add("albert");
		l.add("hello");
		l.add("katappa");

		System.out.println(l);

		l1.addAll(l);
		System.out.println(l1);
		
		l.add("Deepika");
		System.out.println(l);
		
		System.out.println(l1.containsAll(l)); // false
		System.out.println(l1.containsAll(l1)); // true
	}
}

/*Case 1 :----

[abc, albert, alber, hello, katappa]
[abc, albert, alber, hello, katappa]
false
[abc, albert, alber, hello, katappa, Deepika]
true*/