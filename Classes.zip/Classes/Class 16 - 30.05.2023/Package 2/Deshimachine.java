package com.TCS.Digital;
import com.TCS.Data.Machine;
public class Deshimachine implements Machine
{
    public void rocket()
    {
        System.out.println("Best-Rocket");
    }
}