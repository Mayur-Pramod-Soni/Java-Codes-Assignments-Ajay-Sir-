package com.TCS.Data;  // Package file must be file of program
public interface Machine
{
    public void rocket();
}