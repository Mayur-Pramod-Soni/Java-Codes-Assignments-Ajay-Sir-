package dcom.IIT.Bombay;
import com.TCS.Data.AI;
import com.TCS.Digital.Deshimachine;
public class Experiments
{
   public static void main( String args [])
   {
      AI obj1 = new AI();
      obj1.display();

      Deshimachine obj2 = new Deshimachine();
      obj2.rocket();
   }
}