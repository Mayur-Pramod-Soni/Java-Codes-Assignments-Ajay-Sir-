package com.TCS.Data;
public class AI
{
    public AI()
    {
        System.out.println("This is AI-Project");
    }
    public void display()
    {
	  System.out.println("This is AI-Result");
    }
}