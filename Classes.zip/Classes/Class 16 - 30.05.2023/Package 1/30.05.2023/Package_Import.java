import CdacIndore.Test;
 class Package_Import
{
      public static void main( String args[])
      {
           System.out.println("This is Main Class");
           Test.obj = new Test();
           obj.display();

      }
}

 