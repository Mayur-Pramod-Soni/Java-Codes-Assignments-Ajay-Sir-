package CdacIndore;
public class Test
{
    public Test()
    {
    	System.out.println("Test Constructor");
    }
    public void display()
    {
        System.out.println("This is class indore");
    }
}