public class Demo50
{
    public static void main ( String args [] )
    {
        System.out.println("This is Main Class");
        CdacIndore.Test obj = new CdacIndore.Test();
        obj.display();
    }
}