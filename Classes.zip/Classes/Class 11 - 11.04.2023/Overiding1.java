class A 
{
    void sum()
    {
    	System.out.println("Logic of Sum of A Class ");
    }
}
class B extends A 
{
	int sum()
	{
		System.out.println("New Logic of Sum in B Class ");
		return 10; // Error - In method overiding return type must be same if it is primitive 
	}
}
class Overiding1 
{
	public static void main(String[] args) 
	{
		B out = new B();
		out.sum();
	}

}
