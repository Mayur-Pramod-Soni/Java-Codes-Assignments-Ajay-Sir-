class A1 
{
    void sum(int x)
    {
    	System.out.println("Logic of Sum of A Class ");
    }
}
class B1 extends A1 
{
	int sum()
	{
		System.out.println("New Logic of Sum in B Class ");
		return 10; // No Error - due to Method Overiding not here removed 
	}
}
public class Overiding2 
{
    public static void main(String[] args)
    {
		B1 obj = new B1();
		obj.sum();
		obj.sum(5);
	}
}
