
class A 
{
	void sum()
	{
		System.out.println("Logic of Sum of A Class");
	}
}

class B extends A 
{
	void sum()
	{
		System.out.println("New Logic of Sum of class B");
	}
}

class Method_OverRiding 
{
     public static void main(String[] args)
     {
		B obj1 = new B();
		obj1.sum();
		A obj2 = new A();
		obj2.sum();
	 }
}
