class Test <T>
{
	T a , b ;
	
	Test(T x ,T y)
	{
		a = x ;
		b = y ;
	}
	void show()
	{
		System.out.println(a);
		System.out.println(b);
	}
}
class BoundedGeneric
{
	public static void main(String args[])
	{
		Test <Number> g2 = new Test <Number> (10 , 30.26);
		g2.show();
	}
} 
