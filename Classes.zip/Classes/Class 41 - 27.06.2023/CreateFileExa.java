import java.io.*;
class CreateFileExa
{
	public static void main(String args[])
	{
		File f = new File("E:/mobile.txt");
		System.out.println(f.exists());
		
		try
		{
		f.createNewFile();
		}
		catch( IOException b)
		{
		}
		System.out.println(f.exists());
	}
}