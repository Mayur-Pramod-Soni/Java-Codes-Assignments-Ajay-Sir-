import java.io.*;

class FileWriter1
{
	public static void main(String args[]) throws IOException
	{
		FileWriter fw = new FileWriter ("Alpha.txt",true);
		
		fw.write('a');
		fw.write(100);
		fw.write("\n");
		fw.write("Welcome");
		fw.write("\n");
		fw.write("Bye");
		fw.flush();
		fw.close();
	}
}