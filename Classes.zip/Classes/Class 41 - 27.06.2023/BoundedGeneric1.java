class Test <A,B>
{
	A a ;
	B b ;
	
	Test(A x ,B y)
	{
		a = x ;
		b = y ;
	}
	void show()
	{
		System.out.println(a);
		System.out.println(b);
	}
}
class BoundedGeneric1
{
	public static void main(String args[])
	{
		Test <Number> g1 = new Test <Number> (10 , 3.25);
		/*Test <Number> g1 = new Test <Number> ( 30.26);
		g2.show();*/
		g1.show();
	}
} 
