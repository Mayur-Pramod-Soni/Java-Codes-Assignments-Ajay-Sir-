import java.io.*;
class CreateFile
{
	public static void main(String args[])
	{
		File f = new File("mobile.txt");
		System.out.println(f.exists());
		
		try
		{
		f.createNewFile();
		}
		catch( IOException b)
		{
		}
		System.out.println(f.exists());
	}
}