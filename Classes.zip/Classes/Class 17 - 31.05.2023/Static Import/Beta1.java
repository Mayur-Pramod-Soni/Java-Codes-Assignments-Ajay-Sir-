//import java.io.PrintStream;
import static java.lang.System.*;
import static Package5.Gama.*;

public class Beta1 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		out.println("Hello");
		fun();
		System.out.println(x);
		
	}

}
