package Package5;

public class Gama {
	public static int x = 100 ;
	public static void fun()
	{
		System.out.println("This Is Fun");
	}

}
