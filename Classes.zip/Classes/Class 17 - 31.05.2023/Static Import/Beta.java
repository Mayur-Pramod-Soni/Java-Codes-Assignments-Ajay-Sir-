import static java.lang.System.*;


public class Beta
{
      public static void main(String args[])
	{
		out.println("Hello");  // due to import static java .lang.System.*; function not need to write System class
		
	}
}	