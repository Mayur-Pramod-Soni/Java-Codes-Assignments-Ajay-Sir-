class Mythread extends Thread
{
	public void run()
	{
		for(int i= 0 ; i<10 ;i++)
		{
			System.out.println("Hello-Run");
		}
	}
}
class Get_Set_Priority
{
	public static void main(String args[])
	{
		Mythread m = new Mythread();
		m.setPriority(10);
		m.start();

		for(int i = 0; i < 10;  i++)
		{
			System.out.println("Hello Main");
		}
		System.out.println(m.getPriority());
		
		System.out.println(Thread.currentThread().getPriority());
	}
}