class Mythread extends Thread
{
	public void run()
	{
		Thread.yield();
		for(int i=0; i<10 ; i++ )
		{
			System.out.println("Date & Vanue Selection for Party");
			try 
			{
				Thread.sleep(20);
			}
			catch( InterruptedException vv )
			{
				
			}
		}
	}
}
class JoinMethod
{
	public static void main(String args[]) throws InterruptedException
	{
		Mythread m = new Mythread();
		m.start();
		m.join();
		for(int i = 0 ;i < 100 ; i++)
		{
			System.out.println("Card Printed for Goa-Party");
		}
	}
}
				
