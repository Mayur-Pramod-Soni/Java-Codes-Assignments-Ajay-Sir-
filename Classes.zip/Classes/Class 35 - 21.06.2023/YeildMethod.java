class Mythread extends Thread
{
	public void run()
	{
		for(int i = 0 ; i < 10 ; i++)
		{

			System.out.println("Hello-Run");
			Thread.yield();
		}
	}
}
class YeildMethod
{
	public static void main(String args[])
	{
		Mythread m = new Mythread ();

		m.start();
		for(int i = 0 ; i<100 ; i++)
		{
			System.out.println("Hello Mayur");
		}
	}
}