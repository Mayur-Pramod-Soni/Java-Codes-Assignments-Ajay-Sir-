class Mythread extends Thread
{
	public void run()
	{
		System.out.println("Hello Run");
	}
}
class GetPriority
{
	public static void main(String args[])
	{
		Mythread m = new Mythread();
		System.out.println(Thread.currentThread().getPriority());

		Thread.currentThread().setPriority(8);
		System.out.println(Thread.currentThread().getPriority());
		
		System.out.println(m.getPriority());
	}
}
		