class Mythread extends Thread
{
	public void run()
	{
		System.out.println("Hello Run");
	}
}
class CurrentThread
{
	public static void main(String args[])
	{
		Mythread  m = new Mythread();
		System.out.println(m);
		
		System.out.println(Thread.currentThread().getName());
		
		m.setName("Child");
		System.out.println(m.getName());
		
		Thread.currentThread().setName("Parent");
		System.out.println(Thread.currentThread().getName());

		m.start();
	}
}
/*
output:--
Thread[Thread-0,5,main]
main
Child
Parent
Hello Run
*/