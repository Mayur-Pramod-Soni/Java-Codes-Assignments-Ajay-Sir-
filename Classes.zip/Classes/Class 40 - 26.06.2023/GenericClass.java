class Gen<T>
{
	T obj ;
	Gen(T obj)
	{
		this.obj = obj ;
	}
	void  show()
	{
		System.out.println("Values "+obj.getClass().getName());
	}
	public T getobj()
	{
		return obj ;
	}
}
class GenericClass
{
	public static void main(String args[])
	{
		Gen <String> g1 = new Gen <String>("Welcome");
		g1.show();
		System.out.println(g1.getobj());

		Gen <Integer> g2 = new Gen <Integer>(100);
		g2.show();
		System.out.println(g2.getobj());
	}
}
	