@FunctionalInterface
interface X 
{
	abstract public void m1(); // only one abstruct method alllowed in FI
	default void m2() 
	{
	 	System.out.println("Default is not a Access Speicifier " );	
	}
}
class FIProperties1
{
	public static void main(String args[])
	{
		System.out.println("Hello");
		//X obj = new X();
		//obj.m2();
	}
} 