@FunctionalInterface
interface X 
{
	public void m1(); // only one abstruct method alllowed in FI
	public void m2(); // default access specifier
}
class FIProperties
{
	public static void main(String args[])
	{
		System.out.println("Hello");
	}
}

/* Output:-- multiple non-overriding abstract methods found in interface X */ 