class A

{
   // static int count;

    A()
    {
          System.out.println("default constructor");
    }
    A(int x)
    {
          System.out.println(" Para 1 constructor");
    }
    A (int x, int y)
    {
          System.out.println("para 2 constructor");
    } 
    {
          System.out.println ("Initialization Block1");
    }
    //static
    {
          System.out.println ("Initialization Block2");
    }

}

class Static_Initialization

{

     public static void main (String args [] )
     
     {

          A obj1 = new A();

         // A obj2 = new A();

          A obj3 = new A(100);

        // A obj4 = new A (100, 200);

      }

}