interface F2
{
     int x = 100 ;
     int y = 200 ; 
     void hello();
}
abstract class A implements F2
{
}
class B implements F2
{
     public void hello()
     {
          System.out.println("Chalega ya Nahi!");
     }
}
abstract class C implements F2
{
}
class InterFace_3
{
     public static void main(String args [] )
     {
          B obj = new B();
          obj.hello();
         
         // F2 obj1 = new B();
         // obj1.hello();

          //F2 obj2 = new C();
         // obj2.hello();

         //B obj3 = new F2();
          //obj3.hello();      // error: F2 is abstract; cannot be instantiated

     }
}
