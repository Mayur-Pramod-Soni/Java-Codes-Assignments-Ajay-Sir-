interface F1
{
    void hello();
}
interface F2 extends F1
{
    void display();
}
class B implements F2
{
    public void hello()
    {
         System.out.println("Hello-Guys");
    }
    public void display()
    {
        System.out.println("This is Display");
    }
}
class InterFace_5 
{
    public static void main(String args[])
    {
         // B obj = new F2();  // interface ( F2 ) can't make object but can initialise the object 
         F2 obj = new B();
         obj.hello();
         obj.display();
    }
}