interface InterFace_1
{
     int x = 100;
     int y = 200;
     // int z ;
     void hello();
     /* void display() //  error: interface abstract methods cannot have body
     {
     }*/

     public static void main(String args [] )
     {
          System.out.println(x);
          System.out.println(y);
         // System.out.println(z);  //  error: = expected ; due to data member must initialised at the time of declaration

     }
}