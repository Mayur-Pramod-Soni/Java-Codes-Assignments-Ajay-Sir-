interface Interface
{
     int x = 200;
     int y = 100;
      void hello();
}
class Interface_2
{
     public static void main(String args[])
     {
          Interface obj = new Interface_2();  //error: incompatible types: Interface_2 cannot be converted to Interface
     }
}