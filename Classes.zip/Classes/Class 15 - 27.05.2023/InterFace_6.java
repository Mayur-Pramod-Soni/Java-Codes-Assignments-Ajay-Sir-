interface F1
{
    void hello();
}
abstract class Alpha
{
     abstract void display();
}
class B extends Alpha implements F1
{
     public void hello()
     {
          System.out.println("Hello-Guys");
     }
     public void display()
     {
         System.out.println("This is Display");
     }
}
class InterFace_6
{
    public static void main(String args[])
    {
         F1 obj = new B();
         obj.hello();
      
         Alpha obj1 = new B();
         obj1.display();
    }
}