interface MP
{
    void poha();
}
interface MH
{
     void vadaPav();
}
class B implements MP,MH
{
     public void poha()
     {
          System.out.println("Breakfast MP");
     }
     public void vadaPav()
     {
          System.out.println("Breakfast MH");
     }
}
class InterFace_4
{
     public static void main(String args []) 
     {
          MP obj = new B ();
          obj.poha();
        
          MH obj1 = new B();
          obj1.vadaPav();

         // obj.vadaPav();  // error due to vadaPav method initialised in MH interface and object can't access it.
          // object can only access initilised the method in same interface   

               
     }
}