class Person1
{
	int id;
	String name;
	
	Person1(int id ,String name )
	{
		this.id = id ;
		this.name = name ;
	}
}
class DemoObj
{
	public static void main(String args[])
	{
		Person1 obj = new Person1(101 , "Mayur" );

		System.out.println(obj);   // Case 1
		String str = "abc"+obj ;
		System.out.println(str);
 
	}
}

/*
Output:---

Case1:- Person1@15db9742 due to classes provide answer in Hexadecimal Form


*/