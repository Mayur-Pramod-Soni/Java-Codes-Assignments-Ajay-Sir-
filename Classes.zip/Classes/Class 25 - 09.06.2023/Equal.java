class Person1
{
	int id;
	String name;
	
	Person1(int id ,String name)
	{
		this.id = id ;
		this.name = name ;
	}
	public String toString() // to get answer without hexadecimal form
	{
		return id+" : "+name;
	} 
}
class Equal
{
	public static void main(String args[])
	{
		Person1 obj1 = new Person1(101 , "Mayur" );
		Person1 obj2 = new Person1(101 , "Mayur" );

		Person1 obj3 = obj1; // Case 2 
		
		int i = 100; 
		int j = 100;
		
		System.out.println( obj1 == obj2);
		System.out.println( i == j );

		System.out.println(obj3 == obj1); // case 2 

		System.out.println(obj1.equals(obj2)); // Case 3 

		System.out.println(obj1.equals(obj3)); // Case 4 
		
 
	}
}

/*
Output:---

Case-1 :-

false ( Obj 1 == Obj 2 both has Differance address )
true

Case 2:-

true ( due to here obj 3 is reference of obj1 and they obj3 reference address of obj1 )

Case 3 :- 

false ( due to both obj share different addresses )

Case 4:-

true (due to both share same address )


*/