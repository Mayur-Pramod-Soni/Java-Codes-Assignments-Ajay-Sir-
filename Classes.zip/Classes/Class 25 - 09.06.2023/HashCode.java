class Person1
{
	int id;
	String name;

	Person1(int id, String name)
	{
		this.id = id;
		this.name = name ;
	}
	public String toString()
	{
		return id+" : "+name;
	}

	public boolean equals (Person1 p1 )
	{
		return this.id == p1.id && this.name.equals(p1.name);
	}

	public int hashCode()   // overide the method
	{
		return id ;
	}

}
class HashCode
{
	public static void main(String args[])
	{
		Person1 obj1 = new Person1(101 , "Mayur");
		Person1 obj2 = new Person1(102, "Arpan");

		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
	}
}

/* 

Output:---
 
366712642
1829164700

Case 2 : - 

101
101
         override the equals method


*/