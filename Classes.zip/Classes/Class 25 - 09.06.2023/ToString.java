class Person1
{
	int id;
	String name;
	
	Person1(int id ,String name )
	{
		this.id = id ;
		this.name = name ;
	}
	public String toString() // to get answer without hexadecimal form
	{
		return id+" : "+name;
	} 
}
class ToString
{
	public static void main(String args[])
	{
		Person1 obj = new Person1(101 , "Mayur" );

		System.out.println(obj);   // Case 1
		String str = "abc"+obj ;
		System.out.println(str);
 
	}
}

/*
Output:---

Case1:- 101 : Mayur
abc101 : Mayur


*/