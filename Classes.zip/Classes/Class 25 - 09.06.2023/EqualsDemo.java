class Person1
{
	int id;
	String name;

	Person1(int id, String name)
	{
		this.id = id;
		this.name = name ;
	}
	public String toString()
	{
		return id+" : "+name;
	}

	public boolean equals (Person1 p1 )
	{
		return this.id == p1.id && this.name.equals(p1.name);
	}
}
class EqualsDemo
{
	public static void main(String args[])
	{
		Person1 obj1 = new Person1(101 , "Mayur");
		Person1 obj2 = new Person1(101, "Mayur");

		Person1 obj3 = new Person1(101, "Mayur"); // Case 2 

		int i = 100 ;
		int j = 100 ;
		
		System.out.println(obj1.equals(obj2));
		System.out.println(i == j);

		System.out.println(obj1.equals(obj3));  // Case 2 
	}
}

/* 

Output:---
 
true 
true

Case 2 : - 
 
true  override the equals method




*/