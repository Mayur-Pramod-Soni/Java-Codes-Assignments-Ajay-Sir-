class A 
{
    void display()
    {
         System.out.println("A class Display");
    }
}

class B extends A 
{
    void display()
    {
         super.display();
         
         System.out.println("B class Display ");
         
    }
}

class SuperMethod
{
     public static void main( String args [] )
     {
         //B obj = new A (); //  error: incompatible types: A cannot be converted to B

         A obj = new B ();
         // A class Display , B class Display output 

         //B obj = new B ();

         A obj = new A ();  //  error: variable obj is already defined in method main(String[])

         obj.display(); 
     }
}
    
       