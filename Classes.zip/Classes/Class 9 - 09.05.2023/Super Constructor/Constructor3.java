class A2

{
    A2(int x)
    {
         System.out.println("A class Para Constructor");
    }

    A2()
    {
         System.out.println("A class Default Constructor");
    }

    A2(int u, int v)
    {
         System.out.println("A class 2 para Constructor");
    }


}

class B2 extends A2 
{
    B2()
    {
         super(1200,200);
         System.out.println("B class Default Constructor ");
    }
    B2( int y )
    {
         System.out.println("B class para Constructor");
    }
}

class Constructor3
{
     public static void main( String args [] )
     {
         B2 obj = new B2 ();
     }
}
   