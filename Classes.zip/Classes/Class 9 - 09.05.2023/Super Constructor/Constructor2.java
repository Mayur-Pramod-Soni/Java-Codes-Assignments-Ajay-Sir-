class A1
{
    A1()
    {
         System.out.println("A class Default Constructor");
    }
    A1(int x)
    {
         System.out.println("A class Para Constructor");
    }

}

class B1 extends A1 
{
    B1()
    {
         System.out.println("B class Default Constructor ");
    }
    B1( int y )
    {
         System.out.println("B class para Constructor");
    }
}

class Constructor2
{
     public static void main( String args [] )
     {
         B1 obj = new B1 ();
         // B1 obj = new B1 (500);
     }
}
   