class A 
{
    A(int x)
    {
         System.out.println("A class Constructor");
    }
}

class B extends A 
{
    B()
    {
         // super();  see comments;
         super(10);
         	
         System.out.println("B class Constructor ");
    }
}

public class Constructor1
{
     public static void main( String args [] )
     {
         B obj = new B ();
     }
}
    
/* error: constructor A in class A cannot be applied to given types;
         super();
         ^
  required: int
  found: no arguments
  reason: actual and formal argument lists differ in length    */   