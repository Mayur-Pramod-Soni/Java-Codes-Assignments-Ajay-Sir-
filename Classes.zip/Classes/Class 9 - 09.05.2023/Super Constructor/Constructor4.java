class A3

{
    A3(int x)
    {
         this(10,20);
         System.out.println("1");
    }

    A3()
    {
         System.out.println("2");
    }

    A3(int u, int v)
    {
         System.out.println("4");
    }

    A3( int x , double y )
    {
         System.out.println("3");
    }


}

class B3 extends A3 
{
    B3()
    {
         super(100);
         System.out.println("B class Default Constructor ");
    }
    B3( int y )
    {
         super(200);
         System.out.println("6");
    }
}

class C3 extends B3

{ 
     C3()
    {
         System.out.println("7");
    }
}

class Constructor4

{
     public static void main( String args [] )
     {
       C3 obj1 = new C3();
       B3 obj2 = new B3(200);
       A3 obj3 = new A3(10,20);
     }
}
   