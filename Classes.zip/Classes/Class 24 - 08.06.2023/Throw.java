class Throw
{
	public static void main(String args[])
	{
		System.out.println("Welcome-Guys");

		throw new ArithmeticException("byZero");   //  Case-1
		
		/*  // Case-2
		try
		{
			throw new ArithmeticException("byZero");
		}

		catch ( ArithmeticException e )
		{
			System.out.println("OK");
		}
		*/
		

	}

}

/*

Output:---

Case-1:--

Welcome-Guys
Exception in thread "main" java.lang.ArithmeticException: byZero
        at Throw.main(Throw.java:7)

Case-2:--

Welcome-Guys
OK

*/