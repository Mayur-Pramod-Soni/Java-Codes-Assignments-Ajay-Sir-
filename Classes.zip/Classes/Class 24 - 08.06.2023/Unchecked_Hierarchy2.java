import java.io.*; 

class A
{
	void test1()  throws Exception
	{
		test2();
	}
	void test2()  throws Exception
	{
		test3();
	}
	void test3()  throws FileNotFoundException , ArithmeticException 
	{
		 PrintWriter pw = new PrintWriter("ABC1.txt-run");     
		 pw.write("Hello World");
	}
}

class Unchecked_Hierarchy2
{
	public static void main(String args[])
	{
		System.out.println("Welcome-Guys");
		
		A obj = new A() ;
		
		try 
		{
			obj.test3();
		}
		catch( FileNotFoundException vv)
		{
			
		}
	}
} 

/*
Output:---

Welcome-Guys

*/