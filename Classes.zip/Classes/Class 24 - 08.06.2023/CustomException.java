class Valid extends RuntimeException // Exception
{
	Valid (String s )
	{
		super ( s );
	}
}
class Invalid extends RuntimeException // Exception
{
	Invalid (String s)
	{
		super( s );
	}
}
class CustomException
{
	public static void main(String args[])
	{
		System.out.println("Welcome-Guys");
		
		int age = Integer.parseInt(args[0]);
		
		if(age < 0 )
		{
			throw new Invalid("wrong-age");
		}
		else 
		{
			throw new Valid("valid-age");
		}

	}
}

/*
Output:---

case-1 :-- Valid Age

Welcome-Guys
Exception in thread "main" Valid: valid-age
        at CustomException.main(CustomException.java:29)

case-2 :-- Invalid Age

Welcome-Guys
Exception in thread "main" Invalid: wrong-age
        at CustomException.main(CustomException.java:25)

*/