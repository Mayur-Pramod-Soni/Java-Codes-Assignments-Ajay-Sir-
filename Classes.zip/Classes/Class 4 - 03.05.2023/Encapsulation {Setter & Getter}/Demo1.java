import java.lang.*;
class Sample 

{
     private int a = 100 ;
     private int b = 200 ;

     public void seta(int x)
     {
          a = x ;
     }
     public void geta()
     {
          return a ; 
     }
     public void setb(int y)
     {
          b = y ;
     }
     public void geta()
     {
          return b ;
     }
}

class Demo1

{
     public static void main(String args [] )
     {
          Sample obj = new Sample () ; 
          
          obj.seta(100);
          system.out.println(obj.geta());
      
          obj.setb(200);
          system.out.println(obj.getb());
      }
}