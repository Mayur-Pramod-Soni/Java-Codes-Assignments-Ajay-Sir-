class ThreadG
{
	public static void main(String args[])throws InterruptedException
	{	
		System.out.println(Thread.currentThread().getThreadGroup().getName());
		System.out.println(Thread.currentThread().getThreadGroup().getParent().getName());
	
		ThreadGroup tg = new ThreadGroup ("First");
		System.out.println(tg.getName());
		System.out.println(tg.getParent().getName());
		
		Thread t1 = new Thread (tg , "One");
		Thread t2 = new Thread (tg , "Two");
		tg.list();

	}
}

/*

Output:--

main
system
First
main
java.lang.ThreadGroup[name=First,maxpri=10]

*/