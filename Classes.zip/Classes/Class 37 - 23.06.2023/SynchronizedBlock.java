class Display
{
	public void m5(String name)
	{
		System.out.println("Extra Code");
		
		synchronized (this)
		{
			for(int i =0; i<10; i++)
			{
				System.out.println("Hey-Guys");
				try
				{
					Thread.sleep(1000);
				}
				catch(InterruptedException v )
				{
					
				}
				System.out.println(name);
			}

			System.out.println("Extra Code Bad Wala Hai");
		}
	}
}
class Mythread extends Thread
{
	Display d ;
 	String name ; 
	Mythread (Display d , String name )
	{
		this.d = d; 
		this.name = name ;
	}
	public void run()
	{
		d.m5(name);
	}
}
class SynchronizedBlock
{
	public static void main(String args[])throws InterruptedException
	{
		Display d1 = new Display ();
		Mythread t1 = new Mythread(d1,"Mayur");
		Mythread t2 = new Mythread(d1,"Faizel");
		
		t1.start();
		t2.start();
		System.out.println("End");
	}
}	



