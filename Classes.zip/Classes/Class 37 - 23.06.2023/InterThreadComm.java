class InterThreadComm 
{
	public static void main(String args[])
	{
		ThreadB t = new ThreadB();
		t.start();
		System.out.println("Total Sum is = "+t.total);
	}
}
class ThreadB extends Thread
{
	int total = 0 ;
	public void run()
	{
		for(int i = 0 ;i<100 ; i++)
		{
			total=total+i ;
		}
	}
} 