class InterThreadComm1 
{
	public static void main(String args[])throws InterruptedException
	{
		ThreadB t = new ThreadB();
		t.start();
		synchronized(t)
		{
			System.out.println("Waiting for Total to Complete");
			
			t.wait();

			System.out.println("Signal aa Gaya");
		}

		System.out.println("Total Sum is = "+t.total);
	}
}
class ThreadB extends Thread
{
	int total = 0 ;
	public void run()
	{
		synchronized(this)
		{
			for(int i = 0 ;i<=100 ; i++)
			{
				total=total+i ;
			}
			
			System.out.println("Chalo Signal Dete hai");
			this.notify();

		}
		//this.notify();
	}
} 

/* Output:---

Waiting for Total to Complete
Chalo Signal Dete hai
Signal aa Gaya
Total Sum is = 5050

*/


