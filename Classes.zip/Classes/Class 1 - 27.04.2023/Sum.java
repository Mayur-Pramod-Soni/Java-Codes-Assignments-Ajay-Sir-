import java.lang.*;
class Sum
{
   static public void main (String array[])
   {
       int a = 10;
       int b = 20;
       int c = a+b;
        
       System.out.println("Sum of "+a+" and "+b+" is "+c);
       System.out.println("Multiplication is of abc = " +a*b*c);
       System.out.println("Muliplication of " +a+ " and " +b+ " is = " +c);



    }
}