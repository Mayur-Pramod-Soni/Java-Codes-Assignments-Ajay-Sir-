import java.io.*;
class A 
{
	int test1()
	{
		try
		{	
			String str = null ;
			// int x = str.length();  	// Case - 1 
			return 90 ;
		}
		catch(Exception g)
		{
			System.out.println("Problem / ");
			return 30 ;
		}

		return 60 ; // Case 3 

	}	
}

class Unchecked_Exception
{
	public static void main(String args [])
	{
		System.out.println("Welcome Guys");
		A obj = new A () ;
		System.out.println("Done..."+obj.test1());
	}
} 



// Case - 1  Same Code ---  Welcome Guys
//           Problem /
//           Done...30

// Case - 2 ---Welcome  Guys
//          Done...60

// Case - 3  --- error: unreachable statement return 60 ;