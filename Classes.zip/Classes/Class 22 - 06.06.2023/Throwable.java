class Throwable
{
	public static void main(String args [] )
	{
		System.out.println("Welcome Guys");
		try
		{
			String S1 = args [0];
			System.out.println("Deepika-Padukone / String 1 Pass Correctly");
			String S2 = args [1];
			System.out.println("Kattappa / String 2 Pass Correctly ");
			
			int x = Integer.parseInt(S1);
			int y = Integer.parseInt(S2);
			
			System.out.println("Party / Both String Values Corectly Entered Number type ");
			
			int z = x / y ;					
		
			
			System.out.println("Result is : " +z);

			System.out.println("Arithmetic Exception Found Valid " );

		}

		catch(Throwable e)
		{
			System.out.println("Problem / Superclass Expension can handle all types of Exceptions ");
		}
		
		/*
		catch(Exception e)
		{
			System.out.println("Problem / Superclass Expension can handle all types of Exceptions ");
		}
		*/

		/*
		catch(ArrayIndexOutOfBoundsException r1 )
		{
			System.out.println("Please Enter the values or Forgot to enter values");
		}

		catch(ArithmeticException r2 )
		{
			System.out.println("Please Enter other than Zero(0)");
		}

		catch(NumberFormatException r3 )
		{
			System.out.println("Please Enter only Interger ( Number ) Type Values");
		}
		*/

		System.out.println("Done...");
		System.out.println("Most Imp Works...");	
	}
}
			