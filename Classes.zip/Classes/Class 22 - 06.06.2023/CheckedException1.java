import java.io.*;

class  A 
{
	void test1() throws FileNotFoundException 
	{
		test2();
	}
	void test2() throws FileNotFoundException 
	{
		test3();
	}
	void test3() throws FileNotFoundException 
	{
		PrintWriter pw = new PrintWriter("ABC.txt");
			pw.write("Hello");
	}

class CheckedException1
{
	public static void main(String args [] )
	{
		System.out.println("Welcome Guys");
		
		A obj = new A() ;
		

		try
		{
			obj.test1();
		}
		
		catch( FileNotFoundException l )
		{
			System.out.println(" Error Found " );
		}
		/*catch( ArithmeticException p)
		{
			System.out.println("String Can not be Null");
		}*/

		System.out.println("Done...");
		
	}
}
			