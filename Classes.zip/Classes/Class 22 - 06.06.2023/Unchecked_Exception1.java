import java.io.*;
class A 
{
	int test1()
	{
		try
		{	
			String str = null ;
			 int x = str.length(); 
			return 90 ;
		}
		catch(Exception g)
		{
			System.out.println("Problem / ");
			return 30 ;
		}

		System.out.println("Good News");     // error: unreachable statement
                                                //  System.out.println("Good News");
		return 60 ;

	}	
}

class Unchecked_Exception1
{
	public static void main(String args [])
	{
		System.out.println("Welcome Guys");
		A obj = new A () ;
		System.out.println("Done..."+obj.test1());
	}
} 


