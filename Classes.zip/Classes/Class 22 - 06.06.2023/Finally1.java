import java.io.*;
class A 
{
	int test1()
	{
		try
		{
			String str = null ;
			int x = str.length();
		}
		catch(ArithmeticException a )
		{
			System.out.println("Problem");
			return 78 ;
		} 
		finally
		{
			return 80 ;
		}
	}
}
class Finally1
{
	public static void  main(String args[])
	{
		System.out.println("Welcome - Guys");
		A obj = new A () ;
		System.out.println("Done..."+obj.test1());
	}
}