import java.io.*;
import  java.lang.NullPointerException;
class NullPointer
{
	public static void main(String args [] )
	{
		System.out.println("Welcome Guys");
		try
		{
			String str = null; 
			int x = str.length();
			System.out.println(x);
		}
		catch( NullPointerException e )
		{
			System.out.println("String Can not be Null");
		}
		System.out.println("Done...");
		
	}
}
			