

class Mythread extends Thread
{
	static Thread obj;
	public void run()
	{
		try
		{
			obj.join();
		}
		catch(InterruptedException v )
		{
		}
		for(int i=0 ; i<8 ; i++)
		{
			System.out.println("Date & Process will be decided to party");
			try
			{
				Thread.sleep(1000);
			}
			catch (InterruptedException vv )
			{
			}
		}
	}
}
class DeadLock
{
	public static void main(String args[]) throws InterruptedException
	{
		Mythread m = new Mythread();
		Mythread.obj = Thread.currentThread();
		m.start();
		m.join();
		for(int i = 0 ; i<10; i++ )
		{
			System.out.println("Goa Party Card Print");
			try 
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException yy)
			{
			}
		}
	}
}