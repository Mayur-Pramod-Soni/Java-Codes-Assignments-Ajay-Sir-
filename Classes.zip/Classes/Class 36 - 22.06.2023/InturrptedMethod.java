class Mythread extends Thread
{
	public void run()
	{
		for (int i = 0; i<10; i++)
		{
			try
			{
				System.out.println("I'm Sleeping");
				Thread.sleep(1000);
			}
			catch(InterruptedException vv )
			{
			}
		}
	}
}
class InturrptedMethod
{
	public static void main(String args[]) throws InterruptedException
	{
		Mythread m = new Mythread();
		m.start();
		m.interrupted();
		System.out.println("The End!");
	}
}