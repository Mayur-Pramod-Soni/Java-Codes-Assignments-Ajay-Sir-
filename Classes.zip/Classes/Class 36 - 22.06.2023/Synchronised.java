class Display
{
	public synchronized void m1 (String name)
	{
		for(int i=0; i<10; i++)
		{
			System.out.println("Hey-Guys");
		
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException yy)
			{
			
			}	
		
			System.out.println(name);
		}	
	}
}
class Mythread extends Thread
{
	Display d;
	String name;
	Mythread( Display d ,String name) 	
	{
		this.d=d;
		this.name=name;
	}
	public void run() 
	{
		d.m1(name);
	}			
}
class Synchronised
{
	public static void main(String args[])   //throws InterruptedException
	{
		Display d1=new Display();
		Mythread t1=new Mythread(d1,"Prakhar");
		Mythread t2=new Mythread(d1,"Mayur");

		t1.start();
		t2.start();

		System.out.println("end");

	}
}