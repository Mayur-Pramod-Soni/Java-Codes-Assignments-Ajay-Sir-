
/* Here in child thread Wait and Main thread run due 
to join method used in run method in child process*/


class Mythread extends Thread
{
	static Thread obj;
	public void run()
	{
		try
		{
			obj.join();
		}
		catch(InterruptedException v )
		{
		}
		for(int i=0 ; i<8 ; i++)
		{
			System.out.println("Date & Process will be decided to party");
			try
			{
				Thread.sleep(1000);
			}
			catch (InterruptedException vv )
			{
			}
		}
	}
}
class ChildThreadRun
{
	public static void main(String args[])
	{
		Mythread m = new Mythread();
		Mythread.obj = Thread.currentThread();
		m.start();
		
		for(int i = 0 ; i<10; i++ )
		{
			System.out.println("Goa Party Card Print");
			try 
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException yy)
			{
			}
		}
	}
}