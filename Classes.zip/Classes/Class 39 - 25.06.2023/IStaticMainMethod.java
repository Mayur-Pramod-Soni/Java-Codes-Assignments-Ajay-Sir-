interface IStaticMainMethod
{
	public static void main(String args[])
	{
		System.out.println("This is Static void main");
	}
}

/*

output:---

This is Static void main

*/