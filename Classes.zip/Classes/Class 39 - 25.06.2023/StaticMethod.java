interface Left
{
	public static void m1()
	{
		System.out.println("This is Static Method");
	}
}
class StaticMethod
{
	public static void main(String args[])
	{
		Left.m1();
	}
}