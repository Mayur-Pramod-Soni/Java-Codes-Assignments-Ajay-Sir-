interface Left
{
	default void m1()
	{
		System.out.println("Interface Left MEthod");
	}
}
interface Right
{
	default void m1()
	{
		System.out.println("Interface Right MEthod");
	}
}
class A implements Left,Right 
{
	public void m1()
	{
		Left.super.m1();
	}
}
class DefaultExample
{
	public static void main(String args[])
	{
		A obj = new A();
		obj.m1();
	}
}


/* 

output:---

Interface Left MEthod

*/