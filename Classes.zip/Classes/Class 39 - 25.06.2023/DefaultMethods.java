interface IFirst
{
	public void m1();
	public void m2();

	default void change()
	{
		System.out.println("Default Body MEthod");
	}
}
class A implements IFirst
{
	public void m1()
	{
		System.out.println("m1 - A");
	}
	public void m2()
	{
		System.out.println("m2- A");
	}
}
class B implements IFirst
{
	public void m1()
	{
		System.out.println("m1 -B");
	}
	public void m2()
	{
		System.out.println("m2 -B");
	}
	public void change()
	{
		System.out.println("Class B Logic");
	}
}	
class DefaultMethods
{
	public static void main(String args[])
	{
		A obj1 = new A();
		obj1.m1();
		obj1.m2();
		obj1.change();
		
		B obj2 = new B();
		obj2.m1();
		obj2.m2();
		obj2.change();
	}
}

/*

output:--

m1 - A
m2- A
Default Body MEthod
m1 -B
m2 -B
Class B Logic

*/

