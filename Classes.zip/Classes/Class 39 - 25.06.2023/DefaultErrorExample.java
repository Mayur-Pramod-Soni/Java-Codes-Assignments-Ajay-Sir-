interface Left
{
	default void m1()
	{
	}
}
interface Right
{
	default void m1()
	{
	}
}
class DefaultErrorExample implements Right,Left
{
	public static void main(String args[])
	{
		A obj = new A();
		obj.m1();
	}
}


/* 

output:---

 error: class DefaultErrorExample inherits unrelated defaults for m1() from types Right and Left
class DefaultErrorExample implements Right,Left

*/