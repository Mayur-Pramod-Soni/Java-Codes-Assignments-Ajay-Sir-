import java.util.*;
class ForEach
{
	public static void main(String args[])
	{
		Vector<Integer> s = new Vector <Integer> () ;
		s.add(10) ;
		s.add(20);
		s.add(30);
		s.add(40);
		
		System.out.print("Via Collection Print : ");
		System.out.print(s+" "+'\n');

		System.out.println("ForEach loop Print :");
		for(Integer x : s)
		{
			System.out.println(x);
		}
	}
}