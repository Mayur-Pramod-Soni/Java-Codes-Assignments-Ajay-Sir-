import java.util.*;
class Enumeration 
{

	public static void main(String[] args)
	{
				Vector<Integer> s = new Vector<Integer> () ;
				s.add(10) ;
				s.add(20);
				s.add(33);
				s.add(40);
				
				System.out.print("Via Collection Print : ");
				System.out.print(s+" "+'\n');

				System.out.print("ForEach loop Print :");
				for(Integer x : s)
				{
					System.out.print(x+" ");
				}

				Enumeration<Integer> e = s.elements();
				System.out.print("\n"+"Enumeration Result of Program : ");
				while(e.hasMoreElements())
				{
					Integer i = (Integer)e.nextElement();
					if(i%2==0)
					{
					
						System.out.print(i+" ");
					}
				}
	}
	
}
