import java.util.*;
class Linked_List
{
	public static void main(String args[])
	{
		LinkedList<String> l = new LinkedList<String>();
		
		l.add("abc");
		l.add("albert");
		l.addFirst("first");
		l.addLast("Last");
		l.add("Hello");
		l.add("Katapaa");
		l.add("Karina");

		System.out.println(l);
	}
}
