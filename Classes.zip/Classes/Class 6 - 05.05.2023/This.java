class Student 
{
     int id ;
     int  marks;
     
     Student( int id , int marks )
     {
          this.id = id ;
          this.marks = marks;
          System.out.println("2 Para Constructor Called ");
     }
     void display()
     {
          System.out.println ( id );
          System.out.println ( marks );
     }
}
class This
{
     public static void main( String args [] )
     {
          Student obj = new Student ( 101,104 );
          obj.display();
     }
}