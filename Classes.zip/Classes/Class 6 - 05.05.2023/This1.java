class Student 
{
     int id ;
     int  marks;
     
     Student()
     {
          System.out.println("Default");
     }
     Student( int x )
     {
          System.out.println("Single-Inheritence");
     }

     Student( int id , int marks )
     {
          this();
         // this(10); //  error: call to this must be first statement in constructor
         
// 02 this we can't use in a class  error: call to this must be first statement in constructor
          /*this.id = id ;
          this.marks = marks;*/
          System.out.println("2 Para Constructor Called ");
     }
     void display()
     {
          System.out.println ( id );
          System.out.println ( marks );
     }
}
class This1
{
     public static void main( String args [] )
     {
          Student obj = new Student ( 101,104 );
          obj.display();
     }
}