class A 
{
      final int x ; 
      A()
      {
           x = 100 ; 
      }
     /* A ( int x )   //  error: variable x might not have been initialized due to same type of signature
      {
           x = 200 ;
      }*/

      A ( int y )   
      {
          x = 200 ;
      }

     /* A ( int z ,int u  )   
      {
         // x = 200 ;
      }*/
}
class Attribute_Final2
{ 
      public static void main( String args [] )
      {
          A obj = new A () ;
          System.out.println(obj.x);     // output = 100;     
      }
}
