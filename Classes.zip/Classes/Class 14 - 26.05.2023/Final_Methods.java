class A 
{
     final void sum()
     {
          System.out.println("Parent-Final-Sum"); // Error:--- Method Final so, can't be initialised method
     }
     /*void sum()
     {
          System.out.println("Parent-Sum");  //output--- Parent-Sum
     }*/
}
class B extends A 
{
     void sum()
     {
          System.out.println("Child-Sum");
     }
}
class Final_Methods
{
     public static void main(String args[] )
     {
          A obj = new A ();
          obj.sum ();
     }
}