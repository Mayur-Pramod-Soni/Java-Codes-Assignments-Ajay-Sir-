class A 
{
      final int x ; 
      A()
      {
           x = 100 ; 
      }
}
class Attribute_Final1
{
      public static void main( String args [] )
      {
          A obj = new A () ;
          obj.x = 200 ;  // error: cannot assign a value to final variable x ,obj.x = 200 ;

          // final Attribute can be only defined at the time of declaration , constructor or instance initialiazation block .
          
      }
}
