class A 
{
      final int x ;
}
class B extends A 
{
}
class Attribute_Final
{
      public static void main(String args [])
      {
            A obj = new A (); // error: variable x not initialized in the default constructor -- final int x ;
      }
}
