class A 
{
     // final int x ;

     final static int x ;
     A()
     {
     }
     A (int y )
     {
     }
    /* {
         x = 100; // Error :-- we can only initialized final once .
     }*/
     static
     {
         x = 101; 
     }
}
class Instance_final
{
     public static void main( String args [] )
     {
         A obj = new A();
         System.out.println(obj.x);
      }
}
