// method overloading

class Over 

{
     void fun(int a, int b )
     {
          System.out.println(a+b);
     }
     void fun(int a, int b ,int c)
     {
          System.out.println(a+b+c);
     }
     void fun(double a, double b )
     {
          System.out.println(a+b);
     }
}

class Demo3

{
     public static void main( String args [] )
     {
           Over obj = new Over();
           obj.fun ( 100, 200 );
           obj.fun ( 100, 200,300);
           obj.fun ( 97, 24 );
      }
}       