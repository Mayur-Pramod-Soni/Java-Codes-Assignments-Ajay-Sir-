// method overloading

class Over 

{
     void fun(double d )
     {
          System.out.println("Double Type = "+d);  // By Default all values in java is = Double type ;
     }
     void fun(float f)
     {
          System.out.println("Float Type = "+f);
     }
     
}

class Demo4

{
     public static void main( String args [] )
     {
           Over obj1 = new Over();

           obj1.fun ( 12.54f ); // to put float type values need f after end of number;
          
           obj1.fun ( 97.24 );
      }
}       