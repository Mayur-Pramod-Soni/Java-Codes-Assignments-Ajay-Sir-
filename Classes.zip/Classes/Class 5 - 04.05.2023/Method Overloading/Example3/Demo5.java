// method overloading and typecasting

class Over 

{
     void fun(int n )
     {
          System.out.println("Int Type = "+n);  // By Default all values in java is = Double type ;
     }
    /* void fun(float f)
     {
          System.out.println("Float Type = "+f);
     }*/
     
}

class Demo5

{
     public static void main( String args [] )
     {
           Over obj1 = new Over();

           obj1.fun ( 12.54f ); // 2. error: incompatible types: possible lossy conversion from float to int - obj1.fun ( 12.54f ); 
           
          
          // obj1.fun ( 97 );    // 1.example of typecast in which smaller type of parameter initiliaze but larger side of parameter gives error.
      }
}       