// User Defined default constructor :

class Student // Constructor and Class Should be same

{
     int id;
     int marks;
     
     Student() // Constructor and Class Should be same 
     {
          id = 101 ;
          marks = 87 ;
          System.out.println("Constructor Called ");
     }

     /*void student() // Constructor and Class Should be same 
     {
           id = 101 ;
          marks = 87 ;
          System.out.println("Constructor Called ");

     }*/

     void display( )
     {
          int x = id;
          int y = marks ;
          System.out.println ( x );
          System.out.println ( y  );
     }
   
     
}

class Demo6

{
     public static void main( String args [] )
     {
           Student obj = new Student () ;
           //obj.student();
           obj.display();
     }
}       