import java.util.*;

class TreeSet_Buffer
{
	public static void main(String args[])
	{
		TreeSet<StringBuffer> l = new TreeSet<StringBuffer>();
		
		l.add(new StringBuffer("A"));
		l.add(new StringBuffer("B"));
		l.add(new StringBuffer("z"));
		
		System.out.println(l);
	}
}

/* Output:---

Exception in thread "main" java.lang.ClassCastException: java.lang.StringBuffer 
cannot be cast to java.lang.Comparable

*/