import java.util.*;

class Myorder implements Comparator 
{
	public int compare (Object obj1,Object obj2)
	{
		Integer i1 = (Integer)obj1;
		Integer i2 = (Integer)obj2;

		if(i1<i2)
		{
			return +1 ;
		}
		else if(i1>i2)
		{
			return -1 ;
		}
		else
		{
			return 0 ;
		}
	}
}

class ComparatorExa
{
	public static void main(String args[])
	{
		TreeSet<Integer> l = new TreeSet<Integer>(new Myorder());
		
		l.add(10);
		l.add(5);
		l.add(16);
		
		System.out.println(l);
	}
}

/*Output:--
[16, 10, 5]*/