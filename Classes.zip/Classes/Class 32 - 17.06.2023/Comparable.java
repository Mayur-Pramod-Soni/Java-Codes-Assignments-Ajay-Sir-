import java.util.*;

class Myorder implements Comparator
{
	public int compare(Object obj1,Object obj2)
	{
		String i1 = ( String )obj1;
		String i2 = (String )obj2;
		
		return -i1.compareTo(i2);
	}
}
class Comparable
{
	public static void main(String args[])
	{
		TreeSet<String> l = new TreeSet<String>(new Myorder());
		l.add("albert");
		l.add("mayur");
		l.add("xxx");
		l.add("bcd");
		
		System.out.println(l);
		System.out.println("First/Lowest Value: "+l.pollFirst()); 
		System.out.println("Largest/Last Value: "+l.pollLast());       
	}
}


// Output:--[xxx, mayur, bcd, albert]
//First/Lowest Value: xxx
//Largest/Last Value: albert