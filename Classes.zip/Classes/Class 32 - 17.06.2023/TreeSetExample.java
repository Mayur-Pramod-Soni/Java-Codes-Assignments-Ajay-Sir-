import java.util.*;

class TreeSetExample
{
	public static void main(String args[])
	{
		TreeSet<Integer> l = new TreeSet<Integer>();
		
		l.add(35);
		l.add(9);
		l.add(5);
		l.add(10);
		l.add(9);
		l.add(25);
		l.add(51);
		
		System.out.println(l);
		System.out.println(l.first());
		System.out.println(l.last());
		System.out.println(l.headSet(10));
		System.out.println(l.tailSet(10));
		System.out.println(l.subSet(5,35));
		System.out.println(l.subSet(2,21));
		System.out.println(l.comparator());


	}
}

/*
Output:---

[5, 9, 10, 25, 35, 51]
5
51
[5, 9]
[10, 25, 35, 51]
[5, 9, 10, 25]
[5, 9, 10]
null


*/