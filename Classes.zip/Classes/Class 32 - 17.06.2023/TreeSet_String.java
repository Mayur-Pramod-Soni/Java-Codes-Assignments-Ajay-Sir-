import java.util.*;

class TreeSet_String
{
	public static void main(String args[])
	{
		TreeSet<String> l = new TreeSet<String>();
		
		l.add("A");
		l.add("C");
		l.add("x");
		l.add("z");
		
		System.out.println(l);

	}
}

/*
Output:---

[A, C, x, z]

*/