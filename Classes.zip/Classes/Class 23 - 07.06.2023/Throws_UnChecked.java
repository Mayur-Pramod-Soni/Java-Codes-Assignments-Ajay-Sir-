import java.io.*; 

class A
{
	void test1()  //throws FileNotFoundException
	{
		test2();
	}
	void test2() // throws FileNotFoundException
	{
		test3();
	}
	void test3()  //throws FileNotFoundException
	{
		 PrintWriter pw = new PrintWriter("ABC.txt-run");     //("ABC.text - run");
		 pw.write("albert");
		//int z = 5/0;

	}
}

class Throws_UnChecked 
{
	public static void main(String args[])   throws FileNotFoundException //for both checked and unchecked exception case run and same output -- welcome guys
	{
		System.out.println("Welcome-Guys");
		
		A obj = new A() ;
		
		try 
		{
			obj.test1();
		}
		catch( ArithmeticException e)
		{
			
		}
	}
} 

/*
Output:---

Welcome-Guys

*/