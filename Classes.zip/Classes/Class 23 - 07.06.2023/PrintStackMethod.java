import java.io.*;
class A 
{
	int test1()
	{
		try
		{
			String str = null ;
			int x = str.length();
		}

		catch(Exception b )
		{
			b.printStackTrace();		
		} 


		finally
		{
			System.out.println("Problem Solved");
			//return 80 ;
		}
		return 79 ;
	}
}
class PrintStackMethod // by using an object of java.lang.Exception
{
	public static void  main(String args[])
	{
		System.out.println("Welcome - Guys");
		A obj = new A () ;
		System.out.println("Done..."+obj.test1());
	}
}