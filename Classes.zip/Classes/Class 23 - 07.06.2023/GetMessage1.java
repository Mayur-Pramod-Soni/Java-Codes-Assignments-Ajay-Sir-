import java.io.*;
class A 
{
	int test1()
	{
		try
		{
			int x = 5/0 ;
			System.out.println(x);
		}

		catch(Exception b )
		{
			System.out.println(b.getMessage());	
		} 

		return 79 ;
	}
}
class GetMessage1
{
	public static void  main(String args[])
	{
		System.out.println("Welcome - Guys");
		A obj = new A () ;
		System.out.println("Done..."+obj.test1());
	}
}