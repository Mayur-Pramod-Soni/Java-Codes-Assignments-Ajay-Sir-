import java.io.*;

class A 
{
	int test1()
	{
		try
		{
			String str = null ;
			int x = str.length();
		}

		catch(Exception b )
		{
			System.out.println("Problem-Solved");

			System.exit(0);

			return 71 ;
		} 
		finally
		{
			System.out.println("Problem Solved");

			//return 80 ;
		}
		return 79 ;
	}
}
class Finally2
{
	public static void main(String args [])
	{
		System.out.println("Welcome - Guys");
		A obj = new A () ;
		System.out.println("Done..."+obj.test1());
	}
}