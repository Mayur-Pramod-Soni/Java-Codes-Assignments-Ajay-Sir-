import java.io.*; 

class A
{
	void test1() throws FileNotFoundException
	{
		test2();
	}
	void test2() throws FileNotFoundException
	{
		test3();
	}
	void test3() throws FileNotFoundException
	{
		PrintWriter pw = new PrintWriter("ABC.txt-run");     //("ABC.text - run");
		pw.write("albert");
	}
}

class Throws_Checked2 
{
	public static void main(String args[])
	{
		System.out.println("Welcome-Guys");
		
		A obj = new A() ;
		
		try 
		{
			obj.test1();
			//obj.test3();
		}
		catch( FileNotFoundException e)
		{
			
		}
	}
} 