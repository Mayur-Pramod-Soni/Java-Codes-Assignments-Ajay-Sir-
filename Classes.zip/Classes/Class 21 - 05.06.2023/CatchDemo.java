class CatchDemo
{
	public static void main(String args[])
	{
		System.out.println("Welcome Guys");
		try
		{
			System.out.println("Try Start");
			String s1 = args[0];
			System.out.println("End Try");
			
			// Stystem.out.println("Done....");
			
		}
		catch(ArrayIndexOutOfBoundsException r1 ) // when no input given and after many spaces press the Enter Button on Keyboarld
		{
			System.out.println("Please Enter the values or you forgot to enter values ");
		}
		

		System.out.println("Done...");
		System.out.println("Most Imp Work");
	}
}
