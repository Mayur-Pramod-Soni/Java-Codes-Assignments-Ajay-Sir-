import java.lang.*;
class A 
{
     int a; 
     void display()
     {
         System.out.println("Parent Display");
     }
}  
class B extends A 
{
    int b ;
    void display1()
    {
         System.out.println("CHILD Display");
         a = 100; 
         b = 200 ;
         System.out.println(a+b);
    }
}
class Single
{
    public static void main ( String args [] )
    {
        A obj1 = new A ();
        obj1.display();
        // obj1.dispaly1y()
        
        B obj2 = new B () ; 
        obj2.display();
        obj2.display1();
     }
}