
// super keyworld is used for parent and child class both have same features 


class A 
{
    int a ; 
}
class B extends A 
{
     int  e ;
     void set ( int x , int y ) 
     {
          super.a = x;
          a = y ; 
     }
     void sum()
     {
          e =  super.a + a ;
     }
     void display()
     {
          System.out.println("e = "+e );
     }
     
}
 
class Super 
{
     public static void main ( String args [] ) 
     {
          B obj = new B();
          obj.set(101,210);
          obj.sum();
          obj.display();
     }
}