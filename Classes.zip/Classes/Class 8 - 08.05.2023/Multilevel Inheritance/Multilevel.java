import java.lang.*;
class A 
{
     int a; 
     void display()
     {
         System.out.println("Parent Display");
     }
}  
class B extends A 
{
    int b ;
    void display1()
    {
         System.out.println("CHILD Display 1 from class B");
         a = 100; 
         b = 200 ;
         System.out.println(a+b);
    }
}
class C extends B
{
    void display2()
    {
         System.out.println("Child Class 2 from Class C " );
    }
}  

class Multilevel
{
    public static void main ( String args [] )
    {
       // A obj1 = new A ();
        //obj1.display();
        // obj1.dispaly1()
        
       // B obj2 = new B () ; 
       // obj2.display();
        //obj2.display1();

       C obj3 = new C () ; 
       obj3.display2();
       obj3.display1();
       obj3.display();
     }
}