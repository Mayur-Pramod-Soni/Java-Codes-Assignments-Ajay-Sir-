import java.lang.*;
class A 
{
     int a; 
     void display()
     {
         System.out.println("Parent Display");
     }
}  
class B extends A 
{
    int b ;
    void display1()
    {
         System.out.println("CHILD Display 1 from class A");
         a = 100; 
         b = 200 ;
         System.out.println(a+b);
    }
}
class C extends B
{
    int b ; 
    void dispaly2()
    {
         System.out.println("Child Class 2 from Class B " );
         a = 110; 
         b = 200 ;
         System.out.println(b-a);
    }
}  
class D extends B
{
    int c ;
    int d ;
    void display3()
    {
 
         System.out.println("Child class 3 from class B ");
         c  = 102 ; 
         d =  21 ; 
         System.out.println(c*d);
    }
}
   

class Hybrid
{
    public static void main ( String args [] )
    {
       // A obj1 = new A ();
        //obj1.display();
        // obj1.dispaly1y()
        
        B obj2 = new B () ; 
        obj2.display();
        obj2.display1();

       C obj3 = new C () ; 
       obj3.dispaly2();
       // obj3.display1(); Error due to class B method and in Hierarical inheritance property of both classes different .
       obj3.display();

       D obj4 = new D();
       obj4.display3();
       obj4.display1();
       obj4.display();
     }
}