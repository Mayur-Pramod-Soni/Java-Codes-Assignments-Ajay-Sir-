abstract class A 
{
      // void f1(); // Missing Abstract Error  
     abstract void f1();
     void f2()
     {
         System.out.println("Fun-2");
     }
}
abstract class B extends A
{
}
class C extends B
{
     void f1()
     {
           System.out.println("This is c Class");
     }
}
class Abstract_1
{
     public static void main(String args[])
     {
           //  A obj = new A ();  // Errror ---- A is abstract; cannot be instantiated

           //  A obj = new B ();     // Errror ---- B is abstract; cannot be instantiated

            C obj3 = new C();
            obj3.f1();            // output ---  This is c Class

            A obj4 = new C ();
              obj4.f2();         // output ---  Fun-2
              obj4.f1();         // output ---  This is c Class
     }
}
       