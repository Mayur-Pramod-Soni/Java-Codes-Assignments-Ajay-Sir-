abstract class A 
{
      public abstract void fun1();      
      public void fun2()
      {
           System.out.println("Fun-2");
      }
}
class B extends A 
{
      public void fun1()
      {
         // System.out.println("Class-B");
      }
}
class Implimentation
{
      public static void main(String args[])
      {
           // A obj = new A();   // error: fun1() in B cannot override fun1() in A ,attempting to assign weaker access privileges; was public
   
            B obj = new B();  // compile but no output get;
      }
}



// Note :----  In Implementation all rules same as Overiding .