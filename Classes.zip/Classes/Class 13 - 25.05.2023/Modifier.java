class A 
{
     int id = 50;
}
class B extends A
{
     int id = 100;
}
class Modifier
{
     public static void main( String[] args )
     {
          B obj = new B ();
          System.out.println(obj.id);
          A obj1 = new B();
          System.out.println(obj1.id);
     }
}