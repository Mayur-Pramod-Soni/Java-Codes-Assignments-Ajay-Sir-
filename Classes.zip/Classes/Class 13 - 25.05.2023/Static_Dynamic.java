class A 
{
    static void sum ()
    {
         System.out.println("Parent-Sum");
    }
}
class B extends A 
{
   static void sum()
   {
          System.out.println("Child-Sum");
   }
}
class Static_Dynamic
{
   public static void main ( String args [] )
   {
          A obj = new B();
          B obj1 = new B();
          obj.sum();
          obj1.sum();

   }
}