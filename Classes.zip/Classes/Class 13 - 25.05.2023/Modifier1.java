class A 
{
     static void sum()
     {
           System.out.println("Parent-Sum");
     }
}
class B extends A 
{
     static void sum()
     {
           System.out.println("Child-Sum");
     }
}
class Modifier1
{
      public static void main(String args[])
      {
            A obj = new B ();
            obj.sum();    // Output:---- Parent Sum due to Modifier access Parent class 
      }
}