class String_Creation
{
	public static void main(String rags[])
	{
		String str = "hello";
		String s = new String ("Mayur");
		char s1[] = {'A','B','C'};
		String s2 = new String (s1);
		
		System.out.println(str);
		System.out.println(s);
		System.out.println(s2);
	}
}