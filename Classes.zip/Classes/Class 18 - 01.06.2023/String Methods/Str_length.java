class Str_length
{
	public static void main(String rags[])
	{
		String str1 = "Hello";
		String str2 = "Welcome";

		int l = str1.length();
		System.out.println(l);

		System.out.println(str2.length());
		
	}
}