class Str_compareToIgnoreCase
{
	public static void main(String rags[])
	{
		String str1 = "hello";
		String str2 = "HELLO";

		
		System.out.println(str1.compareToIgnoreCase(str2));

		
	}
}