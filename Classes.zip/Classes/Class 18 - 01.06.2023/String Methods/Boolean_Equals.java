class Boolean_Equals
{
	public static void main(String rags[])
	{
		String str1 = "hello";
		String str2 = "hello";
		
		System.out.println(str1.equals(str2));

		String str3 = "hello";
		String str4 = "Hello";
		
		System.out.println(str3.equals(str4));
	}
}