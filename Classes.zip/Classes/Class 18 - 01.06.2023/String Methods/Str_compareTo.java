class Str_compareTo
{
	public static void main(String rags[])
	{
		String str1 = "hello";
		String str2 = "hello";

		
		System.out.println(str1.compareTo(str2));

		String str3 = "Ahello";
		String str4 = "Bhello";		

		System.out.println(str3.compareTo(str4));

		String str5 = "hello";
		String str6 = "Hello";
		
		System.out.println(str5.compareTo(str6));
	}
}