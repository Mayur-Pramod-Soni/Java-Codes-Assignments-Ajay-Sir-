class concat
{
	public static void main(String rags[])
	{
		String str1 = "Hello";
		String str2 = "Welcome";

		String str3 = str1.concat(str2);
		System.out.println(str3);
		
	}
}