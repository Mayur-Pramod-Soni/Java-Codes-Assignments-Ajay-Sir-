class Str_charAt
{
	public static void main(String rags[])
	{
		String str1 = "Hello";
		String str2 = "Welcome";

		
		System.out.println(str1.charAt(0));

		System.out.println(str2.charAt(2));

		System.out.println(str2.charAt(-1)); // StringIndexOutOfBoundsException: String index out of range: -1
		
	}
}