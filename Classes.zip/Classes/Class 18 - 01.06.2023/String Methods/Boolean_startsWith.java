class Boolean_startsWith
{
	public static void main(String args[])
	{
     		String s1 = "ajay singh thakur";
		String s2 = "Hello";
		System.out.println(s1.startsWith(s2));
	}
}