class StrDemo
{
	public static void main(String rags[])
	{
		String str = "Hello";
		String str1 = str + "Welcome";

		System.out.println(str1);
		
	}
}