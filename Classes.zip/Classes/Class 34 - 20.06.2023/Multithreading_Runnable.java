class Mythread implements Runnable
{
	public void run()
	{
		System.out.println("Hello Run(Child)");
	}
}
class Multithreading_Runnable
{
	public static void main(String args[])
	{
		Mythread m = new Mythread();
		Thread t = new Thread(m);
		t.start();
		
		System.out.println("Main");
	}
}