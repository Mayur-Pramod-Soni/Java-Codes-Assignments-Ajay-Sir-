class Mythread extends Thread
{
	public void run()
	{
		System.out.println("Hello Run");
	}
	public void run (int x)
	{
		System.out.println("Hello Run Para ");
	}
}
class MultiThreading2
{
	public static void main(String args[])
	{
		Mythread m = new Mythread();
		m.start();
		//m.run(10);
		System.out.println("Main ");
	}s
}