class Mythread extends Thread
{
	public void run()
	{
		System.out.println("Hello Run");
	}
	public void start()
	{
		super.start();
		System.out.println("Hello Start");
	}
}
class MultiThreading3
{
	public static void main(String args[])
	{
		Mythread m = new Mythread();
		m.start();
		System.out.println("Main");
	}
}